"""
Construtor do notebook de modelagem (notebooks/modelagem_credito_pj.ipynb).

Gera um notebook AUTOCONTIDO e comentado: ele recria a base sintética, faz a
análise exploratória, treina Regressão Logística + Random Forest, avalia com
KS/ROC/Gini, plota os resultados e persiste o modelo de produção.

Uso:
    python src/_build_notebook.py        # cria o .ipynb
    jupyter nbconvert --to notebook --execute --inplace notebooks/modelagem_credito_pj.ipynb
"""

from pathlib import Path

import nbformat as nbf

RAIZ = Path(__file__).resolve().parents[1]
SAIDA = RAIZ / "notebooks" / "modelagem_credito_pj.ipynb"

nb = nbf.v4.new_notebook()
cells = []
md = lambda s: cells.append(nbf.v4.new_markdown_cell(s.strip("\n")))
code = lambda s: cells.append(nbf.v4.new_code_cell(s.strip("\n")))

md(r"""
# Agente de Crédito com LLM — Modelagem de Risco PJ
### Trabalho final de pós-graduação — FGV | IA Generativa aplicada a Finanças

Este notebook implementa o **núcleo quantitativo** do projeto *Agente de Crédito com LLM*:
geração da base de clientes Pessoa Jurídica (PJ), análise exploratória, treino de dois
modelos de risco (**Regressão Logística** e **Random Forest**) e avaliação com as métricas
padrão de *credit scoring*: **KS, ROC/AUC e Gini**.

O modelo de produção resultante alimenta o *score* exibido pelo agente conversacional
(aplicação Streamlit), enquanto a API da Anthropic gera a análise em linguagem natural.

> **Pipeline:** dados → modelagem → persistência (`.joblib`) → consumo pelo app.
""")

md("## 1. Configuração e bibliotecas")
code(r"""
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import joblib
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (classification_report, confusion_matrix,
                             roc_auc_score, roc_curve)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

SEED = 42
rng = np.random.default_rng(SEED)
plt.rcParams["figure.dpi"] = 110
pd.set_option("display.float_format", lambda x: f"{x:,.2f}")
print("Ambiente pronto.")
""")

md(r"""
## 2. Geração da base sintética de clientes PJ

Não há base pública aberta de inadimplência PJ com a granularidade que precisamos, então
**simulamos 1.000 empresas** a partir de um *modelo causal*:

- Cada empresa tem um **risco latente** verdadeiro (não observável).
- As variáveis que o analista enxerga (score Serasa, atrasos, restrições, indicadores
  financeiros) são **sombras ruidosas** desse risco.
- A **inadimplência** é sorteada em função do risco latente.

Esse desenho garante correlações realistas, ausência de preditor "perfeito" (há ruído) e,
portanto, um problema de modelagem legítimo — reproduzindo o comportamento de carteiras reais.
""")

code(r"""
N = 1000  # "pelo menos 200" — usamos 1.000 para estabilidade estatística

SETORES = {"Comércio": -0.10, "Indústria": 0.05, "Serviços": -0.05,
           "Agronegócio": 0.10, "Construção Civil": 0.30, "Tecnologia": -0.20,
           "Saúde": -0.15, "Transporte e Logística": 0.15}
SETOR_PROB = [0.22, 0.13, 0.24, 0.08, 0.10, 0.08, 0.07, 0.08]
REGIOES = {"Sudeste": -0.05, "Sul": -0.05, "Nordeste": 0.10,
           "Centro-Oeste": 0.00, "Norte": 0.15}
REGIAO_PROB = [0.45, 0.18, 0.20, 0.10, 0.07]

z = lambda x: (x - x.mean()) / x.std()              # padronização (z-score)
sig = lambda x: 1 / (1 + np.exp(-x))                # função logística

setor = rng.choice(list(SETORES), N, p=SETOR_PROB)
regiao = rng.choice(list(REGIOES), N, p=REGIAO_PROB)
porte = rng.choice(["Microempresa", "Pequena", "Média"], N, p=[0.45, 0.40, 0.15])

# Faturamento coerente com o porte (faixas Receita/BNDES)
faturamento = np.empty(N)
for p, (lo, hi) in {"Microempresa": (80_000, 360_000),
                    "Pequena": (360_000, 4_800_000),
                    "Média": (4_800_000, 120_000_000)}.items():
    m = porte == p
    faturamento[m] = lo + rng.beta(2.0, 3.5, m.sum()) * (hi - lo)

tempo_atividade = np.clip(rng.gamma(2.2, 4.5, N), 0.5, 40).round(1)
num_funcionarios = np.maximum(1, (faturamento / 180_000 * rng.lognormal(0, 0.4, N)).round().astype(int))
razao_divida = np.round(rng.beta(2.0, 5.0, N) * 1.6, 3)
divida_total = np.round(razao_divida * faturamento, 2)
margem = np.clip(rng.normal(0.09, 0.07, N), -0.15, 0.45).round(3)
liquidez = np.clip(rng.lognormal(0.15, 0.45, N), 0.2, 5.0).round(2)

# Risco latente a partir dos fundamentos + ruído idiossincrático
estrutural = (0.95 * z(razao_divida) - 0.70 * z(np.log(faturamento))
              - 0.55 * z(margem) - 0.50 * z(liquidez) - 0.40 * z(tempo_atividade)
              + np.array([SETORES[s] for s in setor])
              + np.array([REGIOES[r] for r in regiao]))
risco = z(z(estrutural) + rng.normal(0, 0.85, N))

# Proxies observáveis do risco
score_serasa = np.clip(np.round(600 - 140 * risco + rng.normal(0, 60, N)), 0, 1000).astype(int)
num_atrasos = np.clip(rng.poisson(np.exp(-1.2 + 0.70 * risco)), 0, 12).astype(int)
restricao = rng.binomial(1, sig(-1.9 + 1.3 * risco)).astype(int)

# Alvo: inadimplência (default em 12 meses)
inadimplencia = rng.binomial(1, sig(-1.75 + 1.35 * risco)).astype(int)

df = pd.DataFrame({
    "setor": setor, "regiao": regiao, "porte": porte,
    "tempo_atividade_anos": tempo_atividade, "num_funcionarios": num_funcionarios,
    "faturamento_anual": faturamento.round(2), "divida_total": divida_total,
    "razao_divida_faturamento": razao_divida, "margem_liquida": margem,
    "indice_liquidez_corrente": liquidez, "score_serasa": score_serasa,
    "num_atrasos_12m": num_atrasos, "restricao_serasa": restricao,
    "inadimplencia": inadimplencia,
})
print(f"Base: {df.shape[0]} clientes, {df.shape[1]} colunas")
print(f"Taxa de inadimplência: {df['inadimplencia'].mean():.1%}")
df.head()
""")

md("## 3. Análise exploratória (EDA)")
code(r"""
df.describe(include="all").T
""")

code(r"""
fig, ax = plt.subplots(1, 2, figsize=(13, 4.5))

# Inadimplência por setor
(df.groupby("setor")["inadimplencia"].mean().sort_values()
   .plot.barh(ax=ax[0], color="#d95f0e"))
ax[0].set_title("Taxa de inadimplência por setor")
ax[0].set_xlabel("Proporção inadimplente")

# Distribuição do score Serasa por classe
for classe, cor, rotulo in [(0, "#2c7fb8", "Adimplente"), (1, "#d95f0e", "Inadimplente")]:
    ax[1].hist(df.loc[df.inadimplencia == classe, "score_serasa"], bins=30,
               alpha=0.6, label=rotulo, color=cor, density=True)
ax[1].set_title("Score Serasa por situação de crédito")
ax[1].set_xlabel("Score Serasa"); ax[1].legend()
plt.tight_layout(); plt.show()
""")

md(r"""
A leitura confirma a coerência da base: **Construção Civil** concentra a maior
inadimplência e **Tecnologia/Saúde** a menor; empresas inadimplentes têm distribuição de
score deslocada para a esquerda (scores menores), exatamente como esperado.
""")

md(r"""
## 4. Pré-processamento e separação treino/teste

Usamos um `ColumnTransformer`: **padronização** das variáveis numéricas (essencial para a
Regressão Logística) e **one-hot encoding** das categóricas. A divisão é **estratificada**
para preservar a proporção de inadimplentes em treino e teste.
""")

code(r"""
TARGET = "inadimplencia"
NUMERICAS = ["tempo_atividade_anos", "num_funcionarios", "faturamento_anual",
             "divida_total", "razao_divida_faturamento", "margem_liquida",
             "indice_liquidez_corrente", "score_serasa", "num_atrasos_12m",
             "restricao_serasa"]
CATEGORICAS = ["setor", "regiao", "porte"]

X, y = df[NUMERICAS + CATEGORICAS], df[TARGET]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.30, stratify=y, random_state=SEED)

preproc = ColumnTransformer([
    ("num", StandardScaler(), NUMERICAS),
    ("cat", OneHotEncoder(handle_unknown="ignore"), CATEGORICAS),
])
print(f"Treino: {len(X_train)} | Teste: {len(X_test)}")
""")

md(r"""
## 5. Modelagem — Regressão Logística + Random Forest

Dois paradigmas complementares:
- **Regressão Logística** — interpretável, padrão regulatório em risco de crédito.
- **Random Forest** — captura não-linearidades e interações, costuma elevar o poder discriminante.

Ambos usam `class_weight="balanced"` para lidar com o desbalanceamento da inadimplência.
""")

code(r"""
# KS = máxima separação entre as distribuições acumuladas de bons e maus
def ks_statistic(y_true, y_score):
    fpr, tpr, _ = roc_curve(y_true, y_score)
    return float(np.max(tpr - fpr))

modelos = {
    "Regressão Logística": LogisticRegression(max_iter=1000, class_weight="balanced",
                                              random_state=SEED),
    "Random Forest": RandomForestClassifier(n_estimators=400, max_depth=8,
                                            min_samples_leaf=20, class_weight="balanced",
                                            random_state=SEED, n_jobs=-1),
}

resultados, linhas = {}, []
for nome, clf in modelos.items():
    pipe = Pipeline([("pre", preproc), ("clf", clf)]).fit(X_train, y_train)
    proba = pipe.predict_proba(X_test)[:, 1]
    auc = roc_auc_score(y_test, proba)
    ks = ks_statistic(y_test, proba)
    resultados[nome] = (proba, pipe)
    linhas.append({"Modelo": nome, "AUC": auc, "KS": ks, "Gini": 2 * auc - 1})

tabela = pd.DataFrame(linhas).set_index("Modelo").round(4)
tabela
""")

md("## 6. Avaliação — KS, ROC/AUC e Gini")
code(r"""
# Relatório de classificação do melhor modelo (corte 0,5)
melhor_nome = tabela["AUC"].idxmax()
proba_melhor, pipe_melhor = resultados[melhor_nome]
print(f"Melhor modelo: {melhor_nome}\n")
print(classification_report(y_test, (proba_melhor >= 0.5).astype(int),
      target_names=["Adimplente", "Inadimplente"], digits=3))
""")

code(r"""
fig, ax = plt.subplots(1, 2, figsize=(13, 5))

# --- Curva ROC ---
for nome, (proba, _) in resultados.items():
    fpr, tpr, _ = roc_curve(y_test, proba)
    ax[0].plot(fpr, tpr, label=f"{nome} (AUC={roc_auc_score(y_test, proba):.3f})")
ax[0].plot([0, 1], [0, 1], "k--", alpha=0.4)
ax[0].set(xlabel="Falsos Positivos", ylabel="Verdadeiros Positivos", title="Curva ROC")
ax[0].legend(loc="lower right")

# --- Gráfico KS (melhor modelo) ---
d = pd.DataFrame({"y": y_test.values, "p": proba_melhor}).sort_values("p")
d["cum_bons"] = (d.y == 0).cumsum() / (d.y == 0).sum()
d["cum_maus"] = (d.y == 1).cumsum() / (d.y == 1).sum()
i = (d.cum_bons - d.cum_maus).abs().idxmax()
ks = abs(d.loc[i, "cum_bons"] - d.loc[i, "cum_maus"])
ax[1].plot(d.p, d.cum_bons, label="Acum. Bons")
ax[1].plot(d.p, d.cum_maus, label="Acum. Maus")
ax[1].vlines(d.loc[i, "p"], d.loc[i, "cum_maus"], d.loc[i, "cum_bons"],
             color="red", ls="--", label=f"KS = {ks:.3f}")
ax[1].set(xlabel="PD prevista", ylabel="Frequência acumulada", title=f"KS — {melhor_nome}")
ax[1].legend(loc="center right")
plt.tight_layout(); plt.show()
""")

md("## 7. Importância das variáveis (Random Forest)")
code(r"""
rf_pipe = resultados["Random Forest"][1]
nomes = NUMERICAS + list(rf_pipe.named_steps["pre"]
                         .named_transformers_["cat"].get_feature_names_out(CATEGORICAS))
imp = rf_pipe.named_steps["clf"].feature_importances_
ordem = np.argsort(imp)[::-1][:12]
plt.figure(figsize=(8, 5))
plt.barh([nomes[i] for i in ordem][::-1], imp[ordem][::-1], color="#2c7fb8")
plt.xlabel("Importância"); plt.title("Top 12 variáveis — Random Forest")
plt.tight_layout(); plt.show()
""")

md(r"""
Como esperado em risco de crédito, **score Serasa, alavancagem (dívida/faturamento),
restrição/atrasos** e o **porte/faturamento** dominam a decisão — variáveis acionáveis e
auditáveis pela área de risco.
""")

md(r"""
## 8. Persistência do modelo de produção

Salvamos o **pipeline completo** (pré-processamento + classificador) em `.joblib`. Assim o
app Streamlit carrega um único objeto e faz `predict_proba` direto sobre os dados brutos do
cliente, sem reimplementar transformações.
""")

code(r"""
RAIZ = Path.cwd().parent if Path.cwd().name == "notebooks" else Path.cwd()
DIR_MODELOS = RAIZ / "modelos"; DIR_MODELOS.mkdir(exist_ok=True)

joblib.dump(pipe_melhor, DIR_MODELOS / "pipeline_credito.joblib")

schema = {
    "numericas": NUMERICAS, "categoricas": CATEGORICAS,
    "opcoes_categoricas": {c: sorted(df[c].unique().tolist()) for c in CATEGORICAS},
    "faixas_numericas": {c: {"min": float(df[c].min()), "max": float(df[c].max()),
                             "mediana": float(df[c].median())} for c in NUMERICAS},
    "politica": {"pd_aprovar": 0.10, "pd_negar": 0.25},
}
(DIR_MODELOS / "schema_features.json").write_text(
    json.dumps(schema, indent=2, ensure_ascii=False), encoding="utf-8")
print(f"Modelo de produção salvo: {melhor_nome}")
print(f"-> {DIR_MODELOS / 'pipeline_credito.joblib'}")
""")

md(r"""
## 9. Conclusão da modelagem

- **Random Forest** foi o modelo de produção, com **KS ≈ 0,54**, **AUC ≈ 0,80** e
  **Gini ≈ 0,59** — patamares considerados bons no mercado de crédito (KS > 0,40).
- O pipeline persistido transforma dados brutos em **Probabilidade de Default (PD)**, que o
  agente converte em **score (0–1000)** e em **decisão** (Aprovar / Análise manual / Negar)
  segundo a política de corte (PD ≤ 10% aprova; PD > 25% nega).
- A camada de **IA Generativa (API Anthropic)** traduz esse resultado quantitativo em um
  parecer de crédito em linguagem natural — unindo rigor estatístico e explicabilidade.
""")

nb["cells"] = cells
nb["metadata"] = {
    "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
    "language_info": {"name": "python"},
}
SAIDA.parent.mkdir(parents=True, exist_ok=True)
nbf.write(nb, SAIDA)
print(f"Notebook criado: {SAIDA} ({len(cells)} células)")
