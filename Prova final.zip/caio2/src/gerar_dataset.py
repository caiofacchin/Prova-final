"""
Gerador de base sintética de clientes Pessoa Jurídica (PJ) para análise de crédito.

A base é gerada a partir de um *modelo causal* simples: existe um RISCO LATENTE
verdadeiro de cada empresa (não observável diretamente) e todas as variáveis que o
analista enxerga (score Serasa, atrasos, restrições, indicadores financeiros) são
"sombras" ruidosas desse risco. A inadimplência é, por fim, sorteada em função do
risco latente. Esse desenho garante que:

  1. As variáveis tenham correlação realista entre si.
  2. Nenhum preditor isolado seja perfeito (há ruído) -> a modelagem faz sentido.
  3. Os modelos de ML consigam recuperar o sinal (AUC ~0.85), reproduzindo o que se
     observa em carteiras reais de crédito PJ.

Uso:
    python src/gerar_dataset.py
Gera: data/clientes_pj.csv
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# Configuração
# ---------------------------------------------------------------------------
SEED = 42
N_CLIENTES = 1000  # "pelo menos 200" — usamos 1.000 para estabilidade estatística
SAIDA = Path(__file__).resolve().parents[1] / "data" / "clientes_pj.csv"

rng = np.random.default_rng(SEED)

# Setores e seu efeito marginal no risco (positivo = mais arriscado)
SETORES = {
    "Comércio": -0.10,
    "Indústria": 0.05,
    "Serviços": -0.05,
    "Agronegócio": 0.10,
    "Construção Civil": 0.30,
    "Tecnologia": -0.20,
    "Saúde": -0.15,
    "Transporte e Logística": 0.15,
}
SETOR_PROB = [0.22, 0.13, 0.24, 0.08, 0.10, 0.08, 0.07, 0.08]

REGIOES = {
    "Sudeste": -0.05,
    "Sul": -0.05,
    "Nordeste": 0.10,
    "Centro-Oeste": 0.00,
    "Norte": 0.15,
}
REGIAO_PROB = [0.45, 0.18, 0.20, 0.10, 0.07]


def _padroniza(x: np.ndarray) -> np.ndarray:
    """Z-score (média 0, desvio 1)."""
    return (x - x.mean()) / x.std()


def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))


def gerar() -> pd.DataFrame:
    n = N_CLIENTES

    # --- 1. Atributos cadastrais ------------------------------------------
    setor = rng.choice(list(SETORES), size=n, p=SETOR_PROB)
    regiao = rng.choice(list(REGIOES), size=n, p=REGIAO_PROB)

    porte = rng.choice(
        ["Microempresa", "Pequena", "Média"], size=n, p=[0.45, 0.40, 0.15]
    )

    # Faturamento anual coerente com o porte (faixas BNDES/Receita, em R$)
    faturamento = np.empty(n)
    faixas = {
        "Microempresa": (80_000, 360_000),
        "Pequena": (360_000, 4_800_000),
        "Média": (4_800_000, 120_000_000),
    }
    for p, (lo, hi) in faixas.items():
        mask = porte == p
        # lognormal dentro da faixa -> concentra nas empresas menores de cada faixa
        u = rng.beta(2.0, 3.5, mask.sum())
        faturamento[mask] = lo + u * (hi - lo)

    # Tempo de atividade (anos): empresas mais novas tendem a ser mais arriscadas
    tempo_atividade = np.clip(rng.gamma(shape=2.2, scale=4.5, size=n), 0.5, 40).round(1)

    # Número de funcionários, correlacionado com faturamento
    num_funcionarios = np.maximum(
        1, (faturamento / 180_000 * rng.lognormal(0, 0.4, n)).round().astype(int)
    )

    # --- 2. Indicadores financeiros ---------------------------------------
    # Razão dívida/faturamento (alavancagem): Beta deslocada
    razao_divida = np.round(rng.beta(2.0, 5.0, n) * 1.6, 3)
    divida_total = np.round(razao_divida * faturamento, 2)

    # Margem líquida (%), com média por setor
    margem = np.clip(rng.normal(0.09, 0.07, n), -0.15, 0.45).round(3)

    # Índice de liquidez corrente (ativo circ. / passivo circ.)
    liquidez = np.clip(rng.lognormal(mean=0.15, sigma=0.45, size=n), 0.2, 5.0).round(2)

    # --- 3. Risco latente (não observável) --------------------------------
    setor_eff = np.array([SETORES[s] for s in setor])
    regiao_eff = np.array([REGIOES[r] for r in regiao])

    estrutural = (
        0.95 * _padroniza(razao_divida)
        - 0.70 * _padroniza(np.log(faturamento))
        - 0.55 * _padroniza(margem)
        - 0.50 * _padroniza(liquidez)
        - 0.40 * _padroniza(tempo_atividade)
        + setor_eff
        + regiao_eff
    )
    estrutural = _padroniza(estrutural)
    # Ruído idiossincrático: parte do risco NÃO é explicada pelos fundamentos,
    # o que dá valor preditivo ao score/atrasos/restrição.
    risco = _padroniza(estrutural + rng.normal(0, 0.85, n))

    # --- 4. Proxies observáveis do risco ----------------------------------
    # Score Serasa (0-1000): inversamente proporcional ao risco
    score_serasa = np.clip(np.round(600 - 140 * risco + rng.normal(0, 60, n)), 0, 1000)
    score_serasa = score_serasa.astype(int)

    # Atrasos nos últimos 12 meses (contagem)
    num_atrasos = np.clip(
        rng.poisson(np.exp(-1.2 + 0.70 * risco)), 0, 12
    ).astype(int)

    # Restrição ativa no Serasa (negativação)
    restricao = rng.binomial(1, _sigmoid(-1.9 + 1.3 * risco)).astype(int)

    # --- 5. Variável-alvo: inadimplência (default em 12 meses) -------------
    logit = -1.75 + 1.35 * risco
    prob_default = _sigmoid(logit)
    inadimplencia = rng.binomial(1, prob_default).astype(int)

    df = pd.DataFrame(
        {
            "id_cliente": np.arange(1, n + 1),
            "razao_social": [f"Empresa PJ {i:04d} Ltda" for i in range(1, n + 1)],
            "setor": setor,
            "regiao": regiao,
            "porte": porte,
            "tempo_atividade_anos": tempo_atividade,
            "num_funcionarios": num_funcionarios,
            "faturamento_anual": faturamento.round(2),
            "divida_total": divida_total,
            "razao_divida_faturamento": razao_divida,
            "margem_liquida": margem,
            "indice_liquidez_corrente": liquidez,
            "score_serasa": score_serasa,
            "num_atrasos_12m": num_atrasos,
            "restricao_serasa": restricao,
            "inadimplencia": inadimplencia,
        }
    )
    return df


def main() -> None:
    df = gerar()
    SAIDA.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(SAIDA, index=False, encoding="utf-8")
    taxa = df["inadimplencia"].mean()
    print(f"Base gerada: {len(df)} clientes PJ -> {SAIDA}")
    print(f"Taxa de inadimplência: {taxa:.1%}")
    print(f"Colunas: {list(df.columns)}")
    print(df.head().to_string(index=False))


if __name__ == "__main__":
    main()
