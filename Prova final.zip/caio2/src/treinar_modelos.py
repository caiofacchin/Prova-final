"""
Treinamento e avaliação dos modelos de risco de crédito PJ.

Pipeline:
  1. Carrega data/clientes_pj.csv
  2. Separa treino/teste (estratificado)
  3. Pré-processa (padronização de numéricas + one-hot de categóricas)
  4. Treina Regressão Logística e Random Forest
  5. Avalia com KS, ROC/AUC e Gini (padrão de mercado em credit scoring)
  6. Gera gráficos (ROC, KS, importância de variáveis, matriz de confusão)
  7. Persiste o MELHOR pipeline (.joblib) + métricas (.json) + schema p/ o app

Uso:
    python src/treinar_modelos.py
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # backend sem display, para salvar PNGs
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import joblib
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

# ---------------------------------------------------------------------------
RAIZ = Path(__file__).resolve().parents[1]
DADOS = RAIZ / "data" / "clientes_pj.csv"
DIR_MODELOS = RAIZ / "modelos"
DIR_FIG = RAIZ / "docs" / "figuras"
SEED = 42

TARGET = "inadimplencia"
NUMERICAS = [
    "tempo_atividade_anos",
    "num_funcionarios",
    "faturamento_anual",
    "divida_total",
    "razao_divida_faturamento",
    "margem_liquida",
    "indice_liquidez_corrente",
    "score_serasa",
    "num_atrasos_12m",
    "restricao_serasa",
]
CATEGORICAS = ["setor", "regiao", "porte"]

# Política de decisão sobre a Probabilidade de Default (PD)
PD_APROVAR = 0.10   # PD <= 10%  -> Aprovar
PD_NEGAR = 0.25     # PD  > 25%  -> Negar ; entre os dois -> Análise manual


# ---------------------------------------------------------------------------
# Métricas de credit scoring
# ---------------------------------------------------------------------------
def ks_statistic(y_true: np.ndarray, y_score: np.ndarray) -> float:
    """KS = máxima separação entre as distribuições acumuladas de bons e maus."""
    fpr, tpr, _ = roc_curve(y_true, y_score)
    return float(np.max(tpr - fpr))


def avaliar(nome: str, y_true: np.ndarray, y_proba: np.ndarray) -> dict:
    auc = roc_auc_score(y_true, y_proba)
    ks = ks_statistic(y_true, y_proba)
    gini = 2 * auc - 1
    return {"modelo": nome, "auc": auc, "ks": ks, "gini": gini}


# ---------------------------------------------------------------------------
def construir_preprocessador() -> ColumnTransformer:
    return ColumnTransformer(
        transformers=[
            ("num", StandardScaler(), NUMERICAS),
            ("cat", OneHotEncoder(handle_unknown="ignore"), CATEGORICAS),
        ]
    )


def plot_roc(resultados: dict, y_test, caminho: Path) -> None:
    plt.figure(figsize=(6, 5))
    for nome, (proba, _) in resultados.items():
        fpr, tpr, _ = roc_curve(y_test, proba)
        auc = roc_auc_score(y_test, proba)
        plt.plot(fpr, tpr, label=f"{nome} (AUC={auc:.3f})")
    plt.plot([0, 1], [0, 1], "k--", alpha=0.4)
    plt.xlabel("Taxa de Falsos Positivos")
    plt.ylabel("Taxa de Verdadeiros Positivos")
    plt.title("Curva ROC — Modelos de Risco de Crédito PJ")
    plt.legend(loc="lower right")
    plt.tight_layout()
    plt.savefig(caminho, dpi=130)
    plt.close()


def plot_ks(y_test, proba, nome: str, caminho: Path) -> None:
    df = pd.DataFrame({"y": np.asarray(y_test), "p": proba}).sort_values("p")
    maus = (df["y"] == 1).sum()
    bons = (df["y"] == 0).sum()
    df["cum_maus"] = (df["y"] == 1).cumsum() / maus
    df["cum_bons"] = (df["y"] == 0).cumsum() / bons
    df["dist"] = (df["cum_bons"] - df["cum_maus"]).abs()
    idx = df["dist"].idxmax()
    ks = df.loc[idx, "dist"]
    plt.figure(figsize=(6, 5))
    plt.plot(df["p"], df["cum_bons"], label="Acumulado Bons (adimplentes)")
    plt.plot(df["p"], df["cum_maus"], label="Acumulado Maus (inadimplentes)")
    plt.vlines(df.loc[idx, "p"], df.loc[idx, "cum_maus"], df.loc[idx, "cum_bons"],
               color="red", linestyles="dashed", label=f"KS = {ks:.3f}")
    plt.xlabel("Probabilidade de Default (PD)")
    plt.ylabel("Frequência acumulada")
    plt.title(f"Estatística KS — {nome}")
    plt.legend(loc="center right")
    plt.tight_layout()
    plt.savefig(caminho, dpi=130)
    plt.close()


def plot_importancia(pipe: Pipeline, caminho: Path) -> None:
    pre = pipe.named_steps["pre"]
    nomes = list(NUMERICAS) + list(
        pre.named_transformers_["cat"].get_feature_names_out(CATEGORICAS)
    )
    clf = pipe.named_steps["clf"]
    importancias = clf.feature_importances_
    ordem = np.argsort(importancias)[::-1][:15]
    plt.figure(figsize=(7, 6))
    plt.barh([nomes[i] for i in ordem][::-1], importancias[ordem][::-1], color="#2c7fb8")
    plt.xlabel("Importância (Random Forest)")
    plt.title("Top 15 variáveis — Importância no Random Forest")
    plt.tight_layout()
    plt.savefig(caminho, dpi=130)
    plt.close()


def plot_matriz(y_test, y_pred, nome: str, caminho: Path) -> None:
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(5, 4))
    plt.imshow(cm, cmap="Blues")
    for (i, j), v in np.ndenumerate(cm):
        plt.text(j, i, str(v), ha="center", va="center",
                 color="white" if v > cm.max() / 2 else "black", fontsize=13)
    plt.xticks([0, 1], ["Adimplente", "Inadimplente"])
    plt.yticks([0, 1], ["Adimplente", "Inadimplente"])
    plt.xlabel("Previsto")
    plt.ylabel("Real")
    plt.title(f"Matriz de Confusão — {nome}")
    plt.colorbar()
    plt.tight_layout()
    plt.savefig(caminho, dpi=130)
    plt.close()


# ---------------------------------------------------------------------------
def main() -> None:
    DIR_MODELOS.mkdir(exist_ok=True)
    DIR_FIG.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(DADOS)
    X = df[NUMERICAS + CATEGORICAS]
    y = df[TARGET]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.30, stratify=y, random_state=SEED
    )
    print(f"Treino: {len(X_train)} | Teste: {len(X_test)} | "
          f"Inadimplencia treino: {y_train.mean():.1%}")

    modelos = {
        "Regressao Logistica": LogisticRegression(
            max_iter=1000, class_weight="balanced", random_state=SEED
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=400, max_depth=8, min_samples_leaf=20,
            class_weight="balanced", random_state=SEED, n_jobs=-1
        ),
    }

    resultados = {}   # nome -> (proba_test, pipeline)
    metricas = []
    for nome, clf in modelos.items():
        pipe = Pipeline([("pre", construir_preprocessador()), ("clf", clf)])
        pipe.fit(X_train, y_train)
        proba = pipe.predict_proba(X_test)[:, 1]
        m = avaliar(nome, y_test.values, proba)
        metricas.append(m)
        resultados[nome] = (proba, pipe)
        print(f"\n== {nome} ==")
        print(f"  AUC  = {m['auc']:.4f}")
        print(f"  KS   = {m['ks']:.4f}")
        print(f"  Gini = {m['gini']:.4f}")
        y_pred = (proba >= 0.5).astype(int)
        print(classification_report(y_test, y_pred,
              target_names=["Adimplente", "Inadimplente"], digits=3))

    # Melhor modelo por AUC
    melhor = max(metricas, key=lambda d: d["auc"])
    nome_melhor = melhor["modelo"]
    proba_melhor, pipe_melhor = resultados[nome_melhor]
    print(f"\n>>> Melhor modelo: {nome_melhor} (AUC={melhor['auc']:.4f})")

    # --- Gráficos ---------------------------------------------------------
    plot_roc(resultados, y_test, DIR_FIG / "roc.png")
    plot_ks(y_test, proba_melhor, nome_melhor, DIR_FIG / "ks.png")
    plot_matriz(y_test, (proba_melhor >= 0.5).astype(int), nome_melhor,
                DIR_FIG / "matriz_confusao.png")
    if isinstance(pipe_melhor.named_steps["clf"], RandomForestClassifier):
        plot_importancia(pipe_melhor, DIR_FIG / "importancia.png")
    print(f"Graficos salvos em {DIR_FIG}")

    # --- Persistência -----------------------------------------------------
    joblib.dump(pipe_melhor, DIR_MODELOS / "pipeline_credito.joblib")

    # Schema para popular o app Streamlit (opções e faixas)
    schema = {
        "numericas": NUMERICAS,
        "categoricas": CATEGORICAS,
        "opcoes_categoricas": {c: sorted(df[c].unique().tolist()) for c in CATEGORICAS},
        "faixas_numericas": {
            c: {"min": float(df[c].min()), "max": float(df[c].max()),
                "mediana": float(df[c].median())}
            for c in NUMERICAS
        },
        "politica": {"pd_aprovar": PD_APROVAR, "pd_negar": PD_NEGAR},
    }
    (DIR_MODELOS / "schema_features.json").write_text(
        json.dumps(schema, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    relatorio = {
        "modelo_producao": nome_melhor,
        "n_treino": int(len(X_train)),
        "n_teste": int(len(X_test)),
        "taxa_inadimplencia": float(y.mean()),
        "metricas": {m["modelo"]: {k: round(v, 4) for k, v in m.items() if k != "modelo"}
                     for m in metricas},
        "politica_decisao": {"pd_aprovar": PD_APROVAR, "pd_negar": PD_NEGAR},
    }
    (DIR_MODELOS / "metricas.json").write_text(
        json.dumps(relatorio, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(f"Pipeline, schema e metricas salvos em {DIR_MODELOS}")


if __name__ == "__main__":
    main()
