# 🏦 Agente de Crédito PJ com LLM
### Trabalho final de pós-graduação — FGV · IA Generativa aplicada a Finanças

Solução ponta a ponta de **análise de crédito para Pessoa Jurídica (PJ)** que combina
*machine learning* (score de risco) com *IA generativa* (parecer em linguagem natural via
API da Anthropic). O analista insere os dados de uma empresa e o agente devolve:
**análise textual + score (0–1000) + decisão** (Aprovar / Análise manual / Negar).

---

## 📂 Estrutura

```
caio2/
├── README.md
├── requirements.txt
├── data/
│   └── clientes_pj.csv              # base sintética (1.000 PJ) — gerada
├── src/
│   ├── gerar_dataset.py            # 2. Base de dados
│   ├── treinar_modelos.py          # 3. Modelagem (LogReg + RF, KS/AUC/Gini)
│   └── _build_notebook.py          # gera o notebook a partir do código
├── notebooks/
│   └── modelagem_credito_pj.ipynb  # 3. Notebook comentado (com saídas)
├── modelos/
│   ├── pipeline_credito.joblib     # modelo de produção (gerado)
│   ├── schema_features.json        # schema p/ o app (gerado)
│   └── metricas.json               # métricas reais (gerado)
├── app/
│   ├── app_credito.py              # 4. Produto (Streamlit + Anthropic)
│   └── .streamlit/secrets.toml.example
└── docs/
    ├── 01_problema_de_negocio.md   # 1. Problema de negócio
    ├── 02_artigo_academico.md      # 5. Artigo (~2.000 palavras)
    ├── 03_impacto_financeiro.md    # 6. Impacto financeiro
    ├── 04_pitch_executivo.md       # 7. Pitch executivo (12 min)
    └── figuras/                    # ROC, KS, importância, matriz de confusão
```

---

## 🚀 Como executar

```bash
# 1. Ambiente
python -m venv .venv
.venv\Scripts\activate          # Windows  (Linux/Mac: source .venv/bin/activate)
pip install -r requirements.txt

# 2. Gerar a base e treinar os modelos (já versionados, mas reproduzível)
python src/gerar_dataset.py
python src/treinar_modelos.py

# 3. (Opcional) Reexecutar o notebook
python src/_build_notebook.py

# 4. Rodar o produto
setx ANTHROPIC_API_KEY "sk-ant-..."     # ou use app/.streamlit/secrets.toml
streamlit run app/app_credito.py
```

> Sem chave da Anthropic, o app funciona em **modo demonstração** (parecer baseado em regras).

---

## 📊 Resultados (conjunto de teste, 300 empresas)

| Modelo | KS | ROC/AUC | Gini |
|---|---|---|---|
| Regressão Logística | 0,494 | 0,783 | 0,566 |
| **Random Forest (produção)** | **0,543** | **0,797** | **0,594** |

KS > 0,40 e AUC ≈ 0,80 são patamares considerados **bons** em *credit scoring*.

---

## 🧩 Entregáveis (conforme briefing)

1. **Problema de negócio** → `docs/01_problema_de_negocio.md`
2. **Base de dados** → `src/gerar_dataset.py` + `data/clientes_pj.csv`
3. **Modelagem** → `notebooks/modelagem_credito_pj.ipynb` + `src/treinar_modelos.py`
4. **Produto** → `app/app_credito.py`
5. **Artigo** → `docs/02_artigo_academico.md`
6. **Impacto financeiro** → `docs/03_impacto_financeiro.md`
7. **Pitch executivo** → `docs/04_pitch_executivo.md`
